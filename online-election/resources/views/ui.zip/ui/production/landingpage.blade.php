<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Voting Portal</title>
    <!-- icon -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }
        header {
            background:rgb(9, 75, 99);
            color: #fff;
            padding: 10px 0;
        }
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1100px;
            margin: auto;
            padding: 0 20px;
        }
        header a {
            color: #fff;
            text-decoration: none;
            padding: 0 15px;
        }
        .main-banner {
            background: #f4f4f4;
            padding: 60px 20px;
            text-align: center;
        }
        .main-banner h1 {
            margin: 0;
        }
        .main-banner p {
            margin: 20px 0;
        }
        .main-banner a {
           background:rgb(9, 75, 99);;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
        }
        .main-banner img {
            width: 100%;
            height: auto;
        }
        .section {
            padding: 40px 20px;
            text-align: center;
        }
        .section h2 {
            margin-bottom: 20px;
        }
        .election-list {
            list-style: none;
            padding: 0;
        }
        .election-list li {
            background: #f4f4f4;
            margin: 10px 0;
            padding: 20px;
            border: 1px solid #ddd;
        }
        .election-list a {
            background:rgb(9, 75, 99);
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
        footer {
            background:rgb(9, 75, 99);
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        footer a {
            color: #fff;
            text-decoration: none;
            padding: 0 10px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">

                <h1><a href="landingpage.html"><i class="fas fa-balance-scale"></i>E-Voting Portal</a></h1>
            </div>
            <nav>
                <a href="landingpage.html">Home</a>
                <a href="#howitworks">How It Works</a>
                <a href="signup">Sign Up</a>
                <a href="login.html">Log In</a>
            </nav>
        </div>
        
    </header>
    
    
    <div class="main-banner">
        <h1>Welcome to [Company Name] Voting Portal</h1>
        <p>Cast Your Vote and Make Your Voice Heard</p>
        <div class="col-md-12">
        <img src="images/pic2.jpg">
        </div>
        <a href="signup.html">Vote Now</a>
    </div>
    
    <section class="section">
        <h2>Current Elections</h2>
        <ul class="election-list">
            <li>
                <h3>Board of Directors Election 2024</h3>
                <p>Date: June 1 - June 15, 2024</p>
                <a href="signup.html">Learn More</a>
            </li>
            <li>
                <h3>Employee of the Year 2024</h3>
                <p>Date: July 1 - July 7, 2024</p>
                <a href="signup.html">Learn More</a>
            </li>
        </ul>
    </section>
    
    <section class="section">
        <h2 id="howitworks">How It Works</h2>
        <p>Follow these simple steps to cast your vote:</p>
        <p>1. Sign Up or Log In</p>
        <p>2. Select an Election</p>
        <p>3. Cast Your Vote</p>
        <p>4. Confirm Your Vote</p>
    </section>
    
    <footer>
        <p>&copy; 2024 Company Voting Portal</p>
        <a href="#">Privacy Policy</a> | 
        <a href="#">Terms of Service</a> | 
        <a href="#">Contact Us</a>
        <p>Email: support@company.com | Phone: (123) 456-7890</p>
    </footer>
</body>
</html>
