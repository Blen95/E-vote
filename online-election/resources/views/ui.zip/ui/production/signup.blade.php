<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>E-Vote - Login</title>
 
  <!-- Bootstrap -->
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <!-- icon -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="/node_modules/gentelella/build/css/mycustom.css" rel="stylesheet">
  <style>
    .btn-custom{
      background-color:rgb(9, 75, 99);
      color:white;
    }
    .login{
      background-image:url("images/pic4.jpg");
    }
    </style>
</head>
<body class="login">
  <div class="login_wrapper">
    <div class="login_content">
      <h1>Welcome to E-Vote</h1>
      <form action="index.html" method="GET">
        <div>
            <input type="text" class="form-control" placeholder="First-Name" required="" />
          </div>
          <div>
            <input type="text" class="form-control" placeholder="Last-Name" required="" />
          </div>
        <div>
          <input type="text" class="form-control" placeholder="Username" required="" />
        </div>
        <div>
          <input type="password" class="form-control" placeholder="Password" required="" />
        </div>
        <div>
          <button type="submit" class="btn btn-custom">Register</button>
        </div>
        <div class="change_link">
          <p>Already have an account? <a href="login.html">Login</a></p>
        </div>
      </form>
    </div>
    <div class="separator">
      <h1 style="text-align:center;"><i class="fas fa-balance-scale"></i> E-Vote</h1>
      <p>©2024 All Rights Reserved. E-Vote is a modern online voting platform.</p>
    </div>
  </div>
</body>
</html>
